# refinda
Refinda - A Python package for reproducing financial data 

Visit https://kruthof.github.io/projects/refida/ for dataset descriptions.
